#!/bin/sh

conky -c /home/chris/conky/conf/conkyrc-20111230.cpu 2>&1 > /dev/null &
conky -c /home/chris/conky/conf/conkyrc-20111230.tim 2>&1 > /dev/null &
conky -c /home/chris/conky/conf/conkyrc-20111230.net 2>&1 > /dev/null &
conky -c /home/chris/conky/conf/conkyrc-20111230.cal 2>&1 > /dev/null &
